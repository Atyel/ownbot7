import React, { useState } from 'react';
import { Copy, Check, Terminal } from 'lucide-react';

interface Props {
  content: string;
}

interface CodeBlockProps {
  lang: string;
  code: string;
}

const CodeBlock: React.FC<CodeBlockProps> = ({ lang, code }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    if (!code) return;
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error("Failed to copy", err);
    }
  };

  return (
    <div className="rounded-xl overflow-hidden border border-white/10 bg-[#0d1117] my-6 shadow-2xl flex flex-col backdrop-blur-sm group">
      {/* Terminal Header */}
      <div className="bg-[#161b22] px-4 py-3 border-b border-white/5 flex justify-between items-center select-none">
        <div className="flex items-center gap-2">
          {/* Mac-style traffic lights */}
          <div className="flex gap-1.5 mr-2">
            <div className="w-3 h-3 rounded-full bg-red-500/80 shadow-sm" />
            <div className="w-3 h-3 rounded-full bg-yellow-500/80 shadow-sm" />
            <div className="w-3 h-3 rounded-full bg-green-500/80 shadow-sm" />
          </div>
          <Terminal className="w-3 h-3 text-slate-500 ml-2" />
          <span className="font-mono text-xs text-slate-400 font-medium tracking-wide uppercase">
            {lang || 'TERMINAL'}
          </span>
        </div>
        
        <button
          onClick={handleCopy}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-all border border-white/5 hover:border-white/20 active:scale-95"
          title="Copy Code"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-green-400" />
              <span className="text-green-400 text-xs font-bold">COPIED</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span className="text-xs font-bold">COPY</span>
            </>
          )}
        </button>
      </div>
      
      {/* Code Content */}
      <div className="overflow-x-auto p-5 scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-transparent">
        <pre className="font-mono text-sm leading-relaxed text-blue-100 whitespace-pre">
          <code>{code}</code>
        </pre>
      </div>
    </div>
  );
};

const MarkdownRenderer: React.FC<Props> = ({ content }) => {
  const parts = content.split(/(```[\s\S]*?```)/g);

  return (
    <div className="space-y-4 text-slate-200 leading-7 text-sm md:text-base font-light">
      {parts.map((part, index) => {
        if (part.startsWith('```')) {
          const match = part.match(/```([^\n]*)\n([\s\S]*?)```/);
          let lang = '';
          let code = '';
          if (match) {
            lang = match[1].trim();
            code = match[2];
          } else {
            code = part.replace(/```/g, '');
          }
          return <CodeBlock key={index} lang={lang} code={code} />;
        }
        
        return (
          <p key={index} className="whitespace-pre-wrap">
            {part.split(/(\*\*.*?\*\*|`.*?`)/g).map((subPart, i) => {
               if (subPart.startsWith('**') && subPart.endsWith('**')) {
                 return <strong key={i} className="text-white font-bold tracking-wide">{subPart.slice(2, -2)}</strong>;
               }
               if (subPart.startsWith('`') && subPart.endsWith('`')) {
                 return <code key={i} className="bg-indigo-500/20 border border-indigo-500/30 text-indigo-200 px-1.5 py-0.5 rounded-md font-mono text-sm shadow-[0_0_10px_rgba(99,102,241,0.2)]">{subPart.slice(1, -1)}</code>;
               }
               return subPart;
            })}
          </p>
        );
      })}
    </div>
  );
};

export default MarkdownRenderer;