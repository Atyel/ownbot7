import { AttachedFile } from "../types";

export const readFileContent = (file: File): Promise<AttachedFile> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    // Check if likely binary or text. For code capabilities, we mostly care about text.
    // If it's an image, we might want base64, but prompt emphasizes "Reading code/files".
    // We will attempt to read as text first.
    
    reader.onload = (e) => {
      const content = e.target?.result;
      if (typeof content === 'string') {
        resolve({
          name: file.name,
          type: file.type || 'text/plain',
          content: content,
          size: file.size
        });
      } else {
        reject(new Error("Failed to read file as text"));
      }
    };

    reader.onerror = (e) => reject(new Error("File read error"));

    // We assume mostly code/text files for this bot features.
    reader.readAsText(file);
  });
};

export const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};