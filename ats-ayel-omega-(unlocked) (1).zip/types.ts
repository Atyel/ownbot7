export interface AttachedFile {
  name: string;
  type: string;
  content: string; // Text content or base64
  size: number;
}

export interface UserIdentity {
  id: string;
  name: string;
  color: string; // Tailwind color class or hex
  initials: string;
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  sender?: UserIdentity; // New: Identify who sent the message
  text: string;
  timestamp: number;
  attachments?: AttachedFile[];
  isError?: boolean;
}

export enum ProcessingState {
  IDLE = 'IDLE',
  THINKING = 'THINKING',
  STREAMING = 'STREAMING',
  ERROR = 'ERROR'
}