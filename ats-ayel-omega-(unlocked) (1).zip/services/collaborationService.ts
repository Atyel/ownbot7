import { Message, UserIdentity } from '../types';

const CHANNEL_NAME = 'devbot_mesh_v1';

// Types of events we broadcast
export type MeshEvent = 
  | { type: 'USER_MSG'; payload: Message }
  | { type: 'AI_MSG_START'; payload: Message }
  | { type: 'AI_MSG_CHUNK'; payload: { id: string; text: string } }
  | { type: 'PRESENCE_JOIN'; payload: UserIdentity };

class CollaborationService {
  private channel: BroadcastChannel;
  private listeners: Set<(event: MeshEvent) => void>;

  constructor() {
    this.channel = new BroadcastChannel(CHANNEL_NAME);
    this.listeners = new Set();

    this.channel.onmessage = (messageEvent) => {
      const event = messageEvent.data as MeshEvent;
      this.notify(event);
    };
  }

  // Generate a random identity for the current session
  generateIdentity(): UserIdentity {
    const callsigns = ['Alpha', 'Bravo', 'Charlie', 'Delta', 'Echo', 'Foxtrot', 'Vector', 'Omega', 'Nexus', 'Cipher'];
    const colors = [
      'bg-emerald-500', 
      'bg-orange-500', 
      'bg-pink-500', 
      'bg-cyan-500', 
      'bg-rose-500', 
      'bg-yellow-500'
    ];
    
    const randomCallsign = callsigns[Math.floor(Math.random() * callsigns.length)];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    const id = Math.random().toString(36).substr(2, 9);

    return {
      id,
      name: `Engineer ${randomCallsign}`,
      color: randomColor,
      initials: randomCallsign.substring(0, 2).toUpperCase()
    };
  }

  broadcast(event: MeshEvent) {
    this.channel.postMessage(event);
  }

  subscribe(callback: (event: MeshEvent) => void) {
    this.listeners.add(callback);
    return () => this.listeners.delete(callback);
  }

  private notify(event: MeshEvent) {
    this.listeners.forEach(cb => cb(event));
  }
}

export const collaborationService = new CollaborationService();