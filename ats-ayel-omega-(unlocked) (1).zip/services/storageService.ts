import { Message, UserIdentity } from '../types';

const STORAGE_KEYS = {
  MESSAGES: 'devbot_device_storage_messages',
  USER_ID: 'devbot_device_storage_identity',
  IS_INSTALLED: 'devbot_system_installed'
};

export const storageService = {
  saveMessages: (messages: Message[]) => {
    try {
      localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(messages));
    } catch (e) {
      console.error("Device Storage Full", e);
    }
  },

  loadMessages: (): Message[] | null => {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.MESSAGES);
      return data ? JSON.parse(data) : null;
    } catch (e) {
      return null;
    }
  },

  saveIdentity: (identity: UserIdentity) => {
    localStorage.setItem(STORAGE_KEYS.USER_ID, JSON.stringify(identity));
  },

  loadIdentity: (): UserIdentity | null => {
    const data = localStorage.getItem(STORAGE_KEYS.USER_ID);
    return data ? JSON.parse(data) : null;
  },

  checkInstallation: (): boolean => {
    return localStorage.getItem(STORAGE_KEYS.IS_INSTALLED) === 'true';
  },

  completeInstallation: () => {
    localStorage.setItem(STORAGE_KEYS.IS_INSTALLED, 'true');
  },

  factoryReset: () => {
    localStorage.clear();
    window.location.reload();
  }
};