import React, { useState, useRef, useEffect } from 'react';
import { sendMessageStream, resetChat, initializeChat } from './services/geminiService';
import { collaborationService, MeshEvent } from './services/collaborationService';
import { storageService } from './services/storageService';
import { readFileContent, formatFileSize } from './utils/fileHelpers';
import { AttachedFile, Message, ProcessingState, UserIdentity } from './types';
import MarkdownRenderer from './components/MarkdownRenderer';
import { 
  Send, Paperclip, Bot, Trash2, FileCode, Loader2, Cpu, 
  Menu, X, Wifi, Battery, Signal, Terminal, Smartphone, 
  ShieldCheck, HardDrive, CheckCircle2, ChevronLeft, Zap, Activity,
  Gauge, BarChart3, Layers, Check, AlertTriangle, Server, Network
} from 'lucide-react';

// --- CUSTOM HOOKS ---

const useBattery = () => {
  const [battery, setBattery] = useState({ 
    level: 100, 
    charging: false,
    supported: false
  });

  useEffect(() => {
    // @ts-ignore
    if (typeof navigator.getBattery !== 'function') return;

    // @ts-ignore
    navigator.getBattery().then((bm) => {
      const update = () => {
        setBattery({
          level: Math.floor(bm.level * 100),
          charging: bm.charging,
          supported: true
        });
      };
      update();
      bm.addEventListener('levelchange', update);
      bm.addEventListener('chargingchange', update);
    });
  }, []);

  return battery;
};

// --- SUB-COMPONENTS FOR ANDROID OS ---

const StatusBar = () => {
  const [time, setTime] = useState(new Date());
  const { level, charging, supported } = useBattery();

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="h-8 w-full flex justify-between items-center px-6 pt-2 select-none z-50 text-white/90">
      <span className="text-xs font-medium tracking-wide">
        {time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
      </span>
      <div className="flex items-center gap-2">
        <Wifi className="w-3.5 h-3.5" />
        <Signal className="w-3.5 h-3.5" />
        <div className="flex items-center gap-1 min-w-[3rem] justify-end">
          <span className="text-[10px] font-bold">{level}%</span>
          {charging ? (
             <Zap className="w-3.5 h-3.5 text-green-400 fill-current" />
          ) : (
             <Battery className={`w-4 h-4 ${level < 20 ? 'text-red-400' : 'text-white'}`} />
          )}
        </div>
      </div>
    </div>
  );
};

const GesturePill = () => (
  <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-32 h-1 bg-white/40 rounded-full backdrop-blur-md z-50"></div>
);

const BootLoader = ({ onComplete }: { onComplete: () => void }) => {
  const [step, setStep] = useState(0);
  const [logs, setLogs] = useState<string[]>([]);

  useEffect(() => {
    const sequence = async () => {
      // Step 0: Android Logo
      await new Promise(r => setTimeout(r, 1500));
      setStep(1);
      
      // Step 1: Boot Logs
      const bootLines = [
        "Kernel 6.1.0-android16-generic loaded...",
        "Mounting /system as read-only...",
        "Mounting /data as read-write...",
        "Initializing Neural Processing Unit (NPU)...",
        "Loading DevBot Ultra Daemon...",
        "> SU Access Requested...",
        "> Root Privileges: GRANTED",
        "> Injecting into System Process..."
      ];

      for (const line of bootLines) {
        setLogs(prev => [...prev, line]);
        await new Promise(r => setTimeout(r, Math.random() * 300 + 100));
      }

      // Step 2: Permission UI
      setStep(2);
    };
    sequence();
  }, []);

  const handleGrantPermission = () => {
    setStep(3);
    setTimeout(onComplete, 1000);
  };

  if (step === 0) {
    return (
      <div className="w-full h-full bg-black flex flex-col items-center justify-center">
        <div className="text-4xl font-bold tracking-tighter text-white mb-4 animate-pulse">android</div>
        <div className="text-xs text-slate-500 font-mono">POWERED BY GEMINI</div>
      </div>
    );
  }

  if (step === 1) {
    return (
      <div className="w-full h-full bg-black p-8 flex flex-col justify-end font-mono text-[10px] text-green-500">
        <div className="mb-4 text-center">
           <Cpu className="w-12 h-12 text-white mx-auto mb-4 animate-spin-slow" />
           <p className="text-white text-sm font-bold">BOOTLOADER UNLOCKED</p>
        </div>
        <div className="space-y-1 opacity-80">
          {logs.map((log, i) => (
            <div key={i}>{log}</div>
          ))}
          <div className="animate-pulse">_</div>
        </div>
      </div>
    );
  }

  if (step === 2) {
    return (
      <div className="w-full h-full bg-[#121212] flex flex-col items-center justify-center p-8 text-center">
        <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center mb-6 shadow-[0_0_30px_rgba(79,70,229,0.5)]">
          <Bot className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-xl font-bold text-white mb-2">System Setup</h2>
        <p className="text-sm text-slate-400 mb-8">
          DevBot Ultra requires access to local device memory to store conversation history and neural weights.
        </p>
        
        <div className="bg-[#1e1e1e] w-full rounded-xl p-4 mb-8 text-left border border-white/5">
          <div className="flex items-center gap-3 mb-3 text-xs text-slate-300">
            <HardDrive className="w-4 h-4 text-blue-400" />
            <span>Mount /storage/emulated/0</span>
          </div>
          <div className="flex items-center gap-3 text-xs text-slate-300">
            <ShieldCheck className="w-4 h-4 text-green-400" />
            <span>Grant Superuser Access</span>
          </div>
        </div>

        <button 
          onClick={handleGrantPermission}
          className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-full font-medium transition-all active:scale-95"
        >
          Initialize System
        </button>
      </div>
    );
  }

  return <div className="w-full h-full bg-black flex items-center justify-center"><div className="w-full h-1 bg-indigo-600 animate-pulse"></div></div>;
};

// --- MAIN APP COMPONENT ---

type DiagnosticStep = {
  id: string;
  label: string;
  status: 'pending' | 'running' | 'success' | 'error';
};

function App() {
  const [isBooted, setIsBooted] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [files, setFiles] = useState<AttachedFile[]>([]);
  const [processingState, setProcessingState] = useState<ProcessingState>(ProcessingState.IDLE);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  // Device Info State
  const [deviceModel, setDeviceModel] = useState("Unknown Device");
  const battery = useBattery();
  
  // Diagnostics State
  const [isDiagnosticRunning, setIsDiagnosticRunning] = useState(false);
  const [diagnosticSteps, setDiagnosticSteps] = useState<DiagnosticStep[]>([
    { id: 'network', label: 'Network Mesh Uplink', status: 'pending' },
    { id: 'storage', label: 'Storage Integrity', status: 'pending' },
    { id: 'api', label: 'Gemini API Latency', status: 'pending' },
    { id: 'npu', label: 'Neural Core Stress Test', status: 'pending' },
  ]);
  const [finalScore, setFinalScore] = useState<string | null>(null);

  // Collaboration & Identity
  const [currentUser, setCurrentUser] = useState<UserIdentity | null>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // --- BOOT & INSTALLATION LOGIC ---
  useEffect(() => {
    // Detect OS/Device
    const ua = navigator.userAgent;
    let os = "Android 16 (Virtual)";
    if (ua.includes("Win")) os = "Windows Device";
    else if (ua.includes("Mac")) os = "MacOS Device";
    else if (ua.includes("Linux")) os = "Linux Device";
    else if (ua.includes("Android")) os = "Android Device";
    else if (ua.includes("iPhone")) os = "iOS Device";
    setDeviceModel(os);

    const isInstalled = storageService.checkInstallation();
    if (isInstalled) {
      // Fast boot if already installed
      setIsBooted(true);
      loadSystem();
    }
  }, []);

  const loadSystem = () => {
    initializeChat();
    
    // Load Identity
    let identity = storageService.loadIdentity();
    if (!identity) {
      identity = collaborationService.generateIdentity();
      storageService.saveIdentity(identity);
    }
    setCurrentUser(identity);
    collaborationService.broadcast({ type: 'PRESENCE_JOIN', payload: identity });

    // Load History
    const history = storageService.loadMessages();
    if (history && history.length > 0) {
      setMessages(history);
    } else {
      setMessages([{
        id: 'init',
        role: 'model',
        text: "**SYSTEM ROOTED. KERNEL ACTIVE.**\n\nDevBot Ultra is now running on local device memory. I have full access to this terminal context.\n\nInput commands or attach files to begin.",
        timestamp: Date.now()
      }]);
    }
  };

  const handleBootComplete = () => {
    storageService.completeInstallation();
    setIsBooted(true);
    loadSystem();
  };

  const runDiagnostics = async () => {
    setIsDiagnosticRunning(true);
    setFinalScore(null);
    const steps = [...diagnosticSteps];

    const updateStep = (index: number, status: DiagnosticStep['status']) => {
      steps[index].status = status;
      setDiagnosticSteps([...steps]);
    };

    // Reset all
    steps.forEach(s => s.status = 'pending');
    setDiagnosticSteps([...steps]);

    // 1. Network Check
    updateStep(0, 'running');
    await new Promise(r => setTimeout(r, 800));
    updateStep(0, navigator.onLine ? 'success' : 'error');

    // 2. Storage Check
    updateStep(1, 'running');
    await new Promise(r => setTimeout(r, 600));
    try {
      localStorage.setItem('__diag_test__', 'ok');
      localStorage.removeItem('__diag_test__');
      updateStep(1, 'success');
    } catch {
      updateStep(1, 'error');
    }

    // 3. API Check
    updateStep(2, 'running');
    await new Promise(r => setTimeout(r, 1200));
    updateStep(2, 'success'); // Simulated success for UI flow

    // 4. NPU Stress Test
    updateStep(3, 'running');
    await new Promise(r => setTimeout(r, 2000));
    updateStep(3, 'success');

    setIsDiagnosticRunning(false);
    setFinalScore('98/100');
  };

  // --- PERSISTENCE ---
  useEffect(() => {
    if (messages.length > 0 && isBooted) {
      storageService.saveMessages(messages);
    }
  }, [messages, isBooted]);

  // --- MESH NETWORK ---
  useEffect(() => {
    if (!currentUser) return;
    const unsubscribe = collaborationService.subscribe((event: MeshEvent) => {
      switch (event.type) {
        case 'USER_MSG': setMessages(prev => [...prev, event.payload]); break;
        case 'AI_MSG_START': 
          setMessages(prev => [...prev, event.payload]); 
          setProcessingState(ProcessingState.STREAMING); 
          break;
        case 'AI_MSG_CHUNK':
          setMessages(prev => prev.map(msg => msg.id === event.payload.id ? { ...msg, text: event.payload.text } : msg));
          break;
      }
    });
    return () => { unsubscribe(); };
  }, [currentUser]);

  // --- SCROLLING ---
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, processingState]);

  // --- ACTIONS ---
  const handleSendMessage = async () => {
    if ((!inputText.trim() && files.length === 0) || processingState !== ProcessingState.IDLE || !currentUser) return;

    const newUserMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      sender: currentUser,
      text: inputText,
      timestamp: Date.now(),
      attachments: [...files]
    };

    setMessages(prev => [...prev, newUserMessage]);
    setInputText('');
    setFiles([]);
    setProcessingState(ProcessingState.THINKING);
    collaborationService.broadcast({ type: 'USER_MSG', payload: newUserMessage });

    try {
      const aiMessageId = (Date.now() + 1).toString();
      const aiPlaceholder: Message = { id: aiMessageId, role: 'model', text: '', timestamp: Date.now() };
      
      setMessages(prev => [...prev, aiPlaceholder]);
      collaborationService.broadcast({ type: 'AI_MSG_START', payload: aiPlaceholder });
      setProcessingState(ProcessingState.STREAMING);

      const stream = await sendMessageStream(newUserMessage.text, newUserMessage.attachments || []);
      let fullText = '';
      
      for await (const chunk of stream) {
        fullText += chunk;
        setMessages(prev => prev.map(msg => msg.id === aiMessageId ? { ...msg, text: fullText } : msg));
        collaborationService.broadcast({ type: 'AI_MSG_CHUNK', payload: { id: aiMessageId, text: fullText } });
      }
      setProcessingState(ProcessingState.IDLE);
    } catch (error) {
      setProcessingState(ProcessingState.ERROR);
      setMessages(prev => [...prev, { id: Date.now().toString(), role: 'model', text: "KERNEL PANIC: Connection interrupted.", timestamp: Date.now(), isError: true }]);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = [];
      for (let i = 0; i < e.target.files.length; i++) newFiles.push(await readFileContent(e.target.files[i]));
      setFiles(prev => [...prev, ...newFiles]);
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleFactoryReset = () => {
    if(confirm("FACTORY RESET WARNING: This will wipe all data from Device Memory. Continue?")) {
      storageService.factoryReset();
    }
  };

  // --- RENDER ---
  return (
    // PHYSICAL DEVICE CONTAINER
    <div className="relative w-[380px] h-[800px] bg-gray-900 rounded-[3rem] shadow-[0_0_50px_rgba(0,0,0,0.5),inset_0_0_10px_rgba(255,255,255,0.1)] border-[8px] border-gray-800 ring-1 ring-white/10 overflow-hidden">
      
      {/* REFLECTIONS & HARDWARE */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-7 bg-black rounded-b-2xl z-50"></div> {/* Notch/Dynamic Island */}
      <div className="absolute top-0 left-0 w-full h-full rounded-[2.5rem] pointer-events-none shadow-[inset_0_0_20px_rgba(0,0,0,0.8)] z-40"></div> {/* Curved Edge Shadow */}
      <div className="absolute top-24 -right-[10px] w-[3px] h-16 bg-gray-700 rounded-r-md"></div> {/* Power Button */}
      <div className="absolute top-44 -right-[10px] w-[3px] h-24 bg-gray-700 rounded-r-md"></div> {/* Volume Rocker */}

      {/* SCREEN */}
      <div className="w-full h-full bg-[#050505] text-slate-100 flex flex-col relative overflow-hidden rounded-[2.5rem]">
        
        <StatusBar />

        {!isBooted ? (
          <BootLoader onComplete={handleBootComplete} />
        ) : (
          <>
             {/* APP HEADER */}
            <div className="flex items-center justify-between px-5 py-3 border-b border-white/5 bg-[#121212]/50 backdrop-blur-md z-30 mt-6">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-600 flex items-center justify-center shadow-lg">
                  <Terminal className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h1 className="text-sm font-bold text-white tracking-wide">DevBot<span className="text-indigo-400">Ultra</span></h1>
                  <p className="text-[9px] text-green-400 font-mono tracking-wider">ROOTED • V3.2</p>
                </div>
              </div>
              <button onClick={() => setIsMenuOpen(true)} className="p-2 text-slate-400 hover:text-white rounded-full hover:bg-white/10 transition-all">
                <Menu className="w-5 h-5" />
              </button>
            </div>

            {/* SYSTEM MENU OVERLAY */}
            {isMenuOpen && (
              <div className="absolute inset-0 bg-black/90 backdrop-blur-xl z-50 p-6 flex flex-col animate-in slide-in-from-right duration-200">
                <div className="flex justify-between items-center mb-8 mt-8">
                  <h2 className="text-xl font-bold">System Settings</h2>
                  <button onClick={() => setIsMenuOpen(false)} className="p-2 bg-white/10 rounded-full"><X className="w-5 h-5" /></button>
                </div>
                
                <div className="space-y-4 overflow-y-auto pb-10 scrollbar-none max-h-[600px]">
                  
                  {/* POWER DIAGNOSTICS CARD */}
                  <div className="bg-[#1e1e1e] p-5 rounded-2xl border border-white/5 relative overflow-hidden group">
                    <div className="absolute top-0 right-0 p-3 opacity-20">
                      <Zap className="w-20 h-20 -rotate-12 translate-x-4 -translate-y-4" />
                    </div>
                    
                    <div className="text-xs text-slate-400 uppercase mb-3 font-bold tracking-widest flex items-center gap-2">
                       <Activity className="w-3 h-3 text-indigo-400" />
                       Power & Battery
                    </div>
                    
                    <div className="flex items-center justify-between mb-4 relative z-10">
                      <div className="flex items-center gap-4">
                        <div className={`p-3 rounded-xl ${battery.charging ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'} shadow-lg`}>
                          <Zap className="w-6 h-6 fill-current" />
                        </div>
                        <div>
                          <div className="text-3xl font-bold text-white tracking-tighter">{battery.level}%</div>
                          <div className="text-[10px] text-slate-400 font-mono uppercase tracking-wide">
                            {battery.charging ? 'Charging (AC)' : 'Discharging'}
                          </div>
                        </div>
                      </div>
                      
                      {/* Visual Battery Gauge */}
                      <div className="h-16 w-3 bg-slate-800 rounded-full relative overflow-hidden border border-white/10">
                        <div 
                          className={`absolute bottom-0 left-0 w-full ${battery.charging ? 'bg-green-500 shadow-[0_0_10px_#4ade80]' : (battery.level < 20 ? 'bg-red-500 shadow-[0_0_10px_#ef4444]' : 'bg-yellow-500')} transition-all duration-700 ease-out`}
                          style={{ height: `${battery.level}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  {/* FULL SYSTEM DIAGNOSTICS SUITE */}
                  <div className="bg-[#1e1e1e] p-5 rounded-2xl border border-white/5 relative overflow-hidden">
                    <div className="flex items-center justify-between mb-4">
                      <div className="text-xs text-slate-400 uppercase font-bold tracking-widest flex items-center gap-2">
                         <ShieldCheck className="w-3 h-3 text-emerald-400" />
                         System Diagnostics
                      </div>
                      {finalScore && (
                        <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                          SCORE: {finalScore}
                        </span>
                      )}
                    </div>

                    <div className="space-y-3 mb-6">
                      {diagnosticSteps.map((step, idx) => (
                        <div key={step.id} className="flex items-center justify-between p-3 rounded-xl bg-black/20 border border-white/5">
                          <div className="flex items-center gap-3">
                             {step.id === 'network' && <Network className="w-4 h-4 text-slate-500" />}
                             {step.id === 'storage' && <HardDrive className="w-4 h-4 text-slate-500" />}
                             {step.id === 'api' && <Server className="w-4 h-4 text-slate-500" />}
                             {step.id === 'npu' && <Cpu className="w-4 h-4 text-slate-500" />}
                             <span className="text-sm text-slate-300 font-medium">{step.label}</span>
                          </div>
                          
                          {step.status === 'pending' && <div className="w-2 h-2 rounded-full bg-slate-700" />}
                          {step.status === 'running' && <Loader2 className="w-4 h-4 text-indigo-400 animate-spin" />}
                          {step.status === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-400 animate-in zoom-in" />}
                          {step.status === 'error' && <AlertTriangle className="w-4 h-4 text-red-400" />}
                        </div>
                      ))}
                    </div>

                    {!isDiagnosticRunning && !finalScore && (
                      <button 
                        onClick={runDiagnostics}
                        className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold text-xs tracking-wide transition-all active:scale-95 flex items-center justify-center gap-2"
                      >
                        <Activity className="w-4 h-4" />
                        RUN FULL SYSTEM CHECK
                      </button>
                    )}
                    
                    {isDiagnosticRunning && (
                      <div className="w-full py-3 text-center text-xs text-indigo-300 animate-pulse font-mono">
                         > DIAGNOSTIC KERNEL RUNNING...
                      </div>
                    )}

                    {finalScore && (
                       <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-center animate-in fade-in slide-in-from-bottom-2">
                          <div className="text-emerald-400 font-bold text-sm mb-1">ALL SYSTEMS OPERATIONAL</div>
                          <div className="text-[10px] text-emerald-400/70">Performance is nominal. AI Cores ready.</div>
                          <button 
                            onClick={() => { setFinalScore(null); setDiagnosticSteps(prev => prev.map(s => ({...s, status:'pending'}))) }}
                            className="mt-3 text-[10px] text-slate-400 underline decoration-slate-600 hover:text-white"
                          >
                            Reset Diagnostics
                          </button>
                       </div>
                    )}
                  </div>

                  <div className="bg-[#1e1e1e] p-4 rounded-2xl border border-white/5">
                    <div className="text-xs text-slate-400 uppercase mb-2">Device Info</div>
                    <div className="flex items-center gap-3 mb-2">
                       <Smartphone className="w-4 h-4 text-indigo-400"/>
                       <span className="text-sm font-mono">{deviceModel}</span>
                    </div>
                    <div className="flex items-center gap-3">
                       <HardDrive className="w-4 h-4 text-emerald-400"/>
                       <span className="text-sm font-mono">/data/user/0/devbot</span>
                    </div>
                  </div>

                  <div className="bg-[#1e1e1e] p-4 rounded-2xl border border-white/5">
                     <div className="text-xs text-slate-400 uppercase mb-2">User Identity</div>
                     <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-lg ${currentUser?.color} flex items-center justify-center text-white text-xs font-bold`}>
                          {currentUser?.initials}
                        </div>
                        <div className="flex flex-col">
                          <span className="text-sm font-bold">{currentUser?.name}</span>
                          <span className="text-[10px] text-slate-500 font-mono">{currentUser?.id}</span>
                        </div>
                     </div>
                  </div>

                  <button 
                    onClick={handleFactoryReset}
                    className="w-full p-4 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-400 flex items-center gap-3 hover:bg-red-500/20"
                  >
                    <Trash2 className="w-5 h-5" />
                    <div className="text-left">
                      <div className="text-sm font-bold">Factory Reset</div>
                      <div className="text-[10px] opacity-70">Wipe persistent data</div>
                    </div>
                  </button>
                </div>
              </div>
            )}

            {/* CHAT AREA */}
            <div className="flex-1 overflow-y-auto px-4 py-4 space-y-6 scrollbar-none pb-24">
              {messages.map((msg) => (
                <div key={msg.id} className={`flex gap-3 ${msg.role === 'user' && msg.sender?.id === currentUser?.id ? 'flex-row-reverse' : ''}`}>
                  
                  {/* Avatar */}
                  <div className={`w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center shadow-md border border-white/5 ${
                    msg.role === 'model' ? 'bg-indigo-600' : (msg.sender?.color || 'bg-slate-700')
                  }`}>
                    {msg.role === 'model' ? <Bot className="w-4 h-4 text-white" /> : <span className="text-[10px] font-bold text-white">{msg.sender?.initials}</span>}
                  </div>

                  <div className={`flex flex-col max-w-[85%] space-y-1 ${msg.role === 'user' && msg.sender?.id === currentUser?.id ? 'items-end' : 'items-start'}`}>
                    
                    {/* Attachments */}
                    {msg.attachments && msg.attachments.length > 0 && (
                      <div className="flex flex-wrap gap-1 mb-1 justify-end">
                        {msg.attachments.map((f, i) => (
                          <div key={i} className="bg-[#1e1e1e] border border-white/10 px-2 py-1 rounded text-[10px] text-slate-300 flex items-center gap-1">
                            <FileCode className="w-3 h-3" /> {f.name}
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Bubble */}
                    <div className={`px-4 py-3 rounded-2xl shadow-sm text-sm ${
                      msg.role === 'user' && msg.sender?.id === currentUser?.id
                        ? 'bg-indigo-600 text-white rounded-tr-sm'
                        : 'bg-[#1e1e1e] text-slate-200 rounded-tl-sm border border-white/5'
                    }`}>
                      {msg.role === 'model' ? <MarkdownRenderer content={msg.text} /> : <div className="whitespace-pre-wrap">{msg.text}</div>}
                    </div>

                    <span className="text-[9px] text-slate-600 font-mono px-1">
                      {new Date(msg.timestamp).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}
                    </span>
                  </div>
                </div>
              ))}

              {/* Loader */}
              {processingState !== ProcessingState.IDLE && processingState !== ProcessingState.STREAMING && (
                <div className="flex items-center gap-3 text-indigo-400 text-xs px-4 animate-pulse">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>PROCESSING...</span>
                </div>
              )}
              
              <div ref={messagesEndRef} className="h-4" />
            </div>

            {/* INPUT DOCK (ANDROID KEYBOARD STYLE) */}
            <div className="absolute bottom-0 left-0 w-full bg-[#121212]/95 backdrop-blur-xl border-t border-white/5 px-4 pt-3 pb-8 z-40">
              
              {/* File Preview */}
              {files.length > 0 && (
                <div className="flex gap-2 overflow-x-auto pb-2 mb-1 scrollbar-none">
                  {files.map((f, i) => (
                    <div key={i} className="flex items-center gap-2 bg-[#2d2d2d] rounded-lg px-2 py-1 flex-shrink-0">
                      <span className="text-[10px] text-white truncate max-w-[100px]">{f.name}</span>
                      <button onClick={() => setFiles(prev => prev.filter((_, idx) => idx !== i))}><X className="w-3 h-3 text-slate-400" /></button>
                    </div>
                  ))}
                </div>
              )}

              <div className="flex gap-3 items-end">
                <input type="file" multiple ref={fileInputRef} onChange={handleFileUpload} className="hidden" id="mobile-upload" />
                <label htmlFor="mobile-upload" className="w-10 h-10 rounded-full bg-[#2d2d2d] text-slate-300 flex items-center justify-center active:bg-[#3d3d3d] transition-colors">
                  <Paperclip className="w-5 h-5" />
                </label>

                <div className="flex-1 bg-[#1e1e1e] rounded-[1.5rem] border border-white/5 focus-within:border-indigo-500/50 transition-all flex items-center">
                  <textarea
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder="Message..."
                    className="w-full bg-transparent text-white px-4 py-3 text-sm focus:outline-none resize-none h-[46px] scrollbar-none pt-3.5"
                  />
                </div>

                <button 
                  onClick={handleSendMessage}
                  disabled={processingState !== ProcessingState.IDLE}
                  className="w-12 h-12 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow-lg active:scale-95 transition-transform disabled:opacity-50"
                >
                  {processingState !== ProcessingState.IDLE ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <GesturePill />
          </>
        )}
      </div>
    </div>
  );
}

export default App;