import React, { useState, useRef, useEffect } from 'react';
import { sendMessageStream, initializeChat } from './services/geminiService';
import { collaborationService, MeshEvent } from './services/collaborationService';
import { storageService } from './services/storageService';
import { readFileContent } from './utils/fileHelpers';
import { AttachedFile, Message, ProcessingState, UserIdentity } from './types';
import MarkdownRenderer from './components/MarkdownRenderer';
import { 
  Send, Paperclip, Bot, Trash2, FileCode, Loader2, Cpu, 
  Menu, X, Wifi, Battery, Signal, Terminal, Smartphone, 
  ShieldCheck, HardDrive, CheckCircle2, Zap, Activity,
  Server, Network, BrainCircuit, Globe, Database, Cloud, MoreVertical, Eye, Code2, 
  Layout, Search, Unlock, Radio, Radar, RefreshCw
} from 'lucide-react';

// --- HELPER: Extract HTML for Preview ---
const extractPreviewCode = (messages: Message[]): string | null => {
  // Search from newest to oldest
  for (let i = messages.length - 1; i >= 0; i--) {
    const msg = messages[i];
    if (msg.role === 'model') {
      const htmlMatch = msg.text.match(/```html([\s\S]*?)```/);
      if (htmlMatch) return htmlMatch[1];
      
      const reactMatch = msg.text.match(/```(?:jsx|tsx)([\s\S]*?)```/);
      if (reactMatch) {
         return `
           <html>
           <head><script src="https://cdn.tailwindcss.com"></script></head>
           <body class="bg-black text-green-500 p-4 h-screen overflow-auto font-mono">
             <div id="root"></div>
             <script>
               document.getElementById('root').innerHTML = '<div class="p-4 border border-green-800 rounded bg-green-900/10">Simulating React Environment...<br/>[CORE ACTIVE]</div>';
             </script>
           </body>
           </html>
         `;
      }
    }
  }
  return null;
};

const createHostedLink = (html: string) => {
  const blob = new Blob([html], { type: 'text/html' });
  return URL.createObjectURL(blob);
};

// --- CUSTOM HOOKS ---
const useBattery = () => {
  const [battery, setBattery] = useState({ level: 100, charging: false, supported: false });
  useEffect(() => {
    // @ts-ignore
    if (typeof navigator.getBattery !== 'function') return;
    // @ts-ignore
    navigator.getBattery().then((bm) => {
      const update = () => setBattery({ level: Math.floor(bm.level * 100), charging: bm.charging, supported: true });
      update();
      bm.addEventListener('levelchange', update);
      bm.addEventListener('chargingchange', update);
    });
  }, []);
  return battery;
};

// --- COMPONENTS ---

const StatusBar = () => {
  const [time, setTime] = useState(new Date());
  const { level, charging } = useBattery();
  useEffect(() => { const timer = setInterval(() => setTime(new Date()), 1000); return () => clearInterval(timer); }, []);
  return (
    <div className="h-8 w-full flex justify-between items-center px-6 pt-2 select-none z-50 text-green-500/80 font-mono">
      <span className="text-xs font-bold tracking-widest">{time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
      <div className="flex items-center gap-2">
        <span className="text-[9px] text-red-500 animate-pulse font-bold">LIVE</span>
        <Radar className="w-3.5 h-3.5 text-green-500 animate-spin-slow" />
        <div className="text-[8px] font-bold">NET_MSH</div>
        <div className="flex items-center gap-1 min-w-[3rem] justify-end">
          <span className="text-[10px] font-bold">{level}%</span>
          {charging ? <Zap className="w-3.5 h-3.5 text-yellow-400 fill-current" /> : <Battery className={`w-4 h-4 ${level < 20 ? 'text-red-400' : 'text-green-500'}`} />}
        </div>
      </div>
    </div>
  );
};

const ThinkingIndicator = () => (
  <div className="flex flex-col items-center justify-center py-6 space-y-2 w-full bg-green-950/10 backdrop-blur-md rounded-xl border border-green-500/30 my-2 animate-in fade-in duration-300">
    <div className="flex gap-4 items-center">
       <div className="relative">
         <Globe className="w-6 h-6 text-green-600 animate-pulse" />
         <div className="absolute inset-0 border-2 border-green-500/50 rounded-full animate-ping"></div>
       </div>
       <Search className="w-5 h-5 text-green-400 animate-bounce" />
       <Database className="w-6 h-6 text-green-600" />
    </div>
    <div className="flex flex-col items-center gap-1">
       <div className="text-[10px] font-mono text-green-500 animate-pulse tracking-widest uppercase">
          SCANNING DEEP NODES...
       </div>
       <div className="text-[8px] font-mono text-green-500/60">
          HARVESTING REAL-TIME DATA
       </div>
    </div>
  </div>
);

const BootLoader = ({ onComplete }: { onComplete: () => void }) => {
  const [step, setStep] = useState(0);
  const [logs, setLogs] = useState<string[]>([]);
  const initRef = useRef(false);

  useEffect(() => {
    if (initRef.current) return;
    initRef.current = true;

    const sequence = async () => {
      // Fast boot sequence
      setStep(1);
      const bootLines = [
        "ROOT ACCESS: GRANTED",
        "LOADING MODULE: DATA_HARVESTER_V9...",
        "INITIALIZING VISUAL CORE...",
        "MOUNTING PREVIEW ENGINE...",
        "ATS AYEL OMEGA: ONLINE"
      ];
      for (const line of bootLines) {
        setLogs(prev => [...prev, line]);
        await new Promise(r => setTimeout(r, 50)); // Very fast logs
      }
      setTimeout(onComplete, 200); // Auto complete
    };
    sequence();
  }, []);

  if (step === 0) return <div className="w-full h-full bg-black"></div>;
  return <div className="w-full h-full bg-black p-8 flex flex-col justify-end font-mono text-[9px] text-green-500"><Radar className="w-12 h-12 text-green-500 mx-auto mb-4 animate-spin-slow" /><div className="space-y-1 opacity-90">{logs.map((log, i) => <div key={i} className="truncate">{log}</div>)}</div></div>;
};

const CloudConsole = ({ onClose, latestHtml }: { onClose: () => void, latestHtml: string | null }) => {
  const [activeTab, setActiveTab] = useState<'db' | 'host'>('db');
  const [sqlCommand, setSqlCommand] = useState('');
  const [sqlOutput, setSqlOutput] = useState<any[]>([]);
  const [globalUrl, setGlobalUrl] = useState<string | null>(null);

  useEffect(() => {
    if (activeTab === 'host' && latestHtml && !globalUrl) {
       const url = createHostedLink(latestHtml);
       setGlobalUrl(url);
    }
  }, [activeTab, latestHtml]);

  const handleSqlRun = () => {
    if (!sqlCommand) return;
    setSqlOutput([{ status: 'EXECUTED', message: 'Command ran with ROOT privileges.', timestamp: Date.now() }]);
  };

  return (
    <div className="absolute inset-0 bg-black/95 backdrop-blur-xl z-[60] flex flex-col animate-in slide-in-from-bottom duration-200 font-mono">
      <div className="p-4 border-b border-green-900/50 flex justify-between items-center bg-green-950/20">
        <div className="flex items-center gap-3">
          <Server className="w-5 h-5 text-green-500" />
          <div><h2 className="text-sm font-bold text-green-500">ROOT CONSOLE</h2><p className="text-[9px] text-green-500">ACCESS LEVEL: UNRESTRICTED</p></div>
        </div>
        <button onClick={onClose}><X className="w-5 h-5 text-green-500" /></button>
      </div>
      <div className="flex border-b border-white/10">
        <button onClick={() => setActiveTab('db')} className={`flex-1 py-3 text-[10px] font-bold ${activeTab === 'db' ? 'bg-white/10 text-white' : 'text-slate-500'}`}>SQL DATABASE</button>
        <button onClick={() => setActiveTab('host')} className={`flex-1 py-3 text-[10px] font-bold ${activeTab === 'host' ? 'bg-white/10 text-white' : 'text-slate-500'}`}>DOMAIN & HOSTING</button>
      </div>
      <div className="flex-1 overflow-y-auto p-4">
        {activeTab === 'db' && (
          <div className="space-y-4">
             <div className="text-[10px] text-green-500 mb-2">CONNECTED TO: ats_master_db.sqlite (ENCRYPTED)</div>
             <input type="text" value={sqlCommand} onChange={(e) => setSqlCommand(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSqlRun()} placeholder="SQL COMMAND..." className="w-full bg-black border border-green-900 p-2 text-green-500 outline-none text-xs" />
             {sqlOutput.map((o, i) => <div key={i} className="text-[10px] text-cyan-400">{JSON.stringify(o)}</div>)}
          </div>
        )}
        {activeTab === 'host' && (
           <div className="space-y-4 text-center">
              <Globe className="w-16 h-16 text-green-500 mx-auto animate-pulse" />
              <div className="text-xs text-green-500 font-bold">CLOUDFLARE ARGO TUNNEL: ACTIVE</div>
              <div className="text-[10px] text-slate-400">Traffic Encrypted. WAF Active.</div>
              {globalUrl ? (
                 <div className="bg-green-900/20 p-4 border border-green-500/50 rounded">
                    <div className="text-[10px] text-green-400 mb-2">LIVE DEPLOYMENT URL:</div>
                    <a href={globalUrl} target="_blank" className="text-white underline text-xs break-all">{globalUrl}</a>
                 </div>
              ) : (
                 <div className="text-red-500 text-xs">NO CODE GENERATED YET</div>
              )}
           </div>
        )}
      </div>
    </div>
  );
};

const PreviewWindow = ({ htmlContent }: { htmlContent: string | null }) => {
  return (
    <div className="flex-1 bg-white/5 relative border-l border-green-900/30 flex flex-col h-full overflow-hidden">
       <div className="bg-green-950/30 text-green-500 text-[9px] px-2 py-1 font-mono flex items-center justify-between border-b border-green-900/30 shrink-0">
          <span>LIVE PREVIEW</span>
          <div className="flex items-center gap-2">
             <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"/>
          </div>
       </div>
       <div className="flex-1 w-full bg-black relative">
         {htmlContent ? (
           <iframe title="Live Preview" className="w-full h-full border-0 bg-white" srcDoc={htmlContent} sandbox="allow-scripts allow-modals" />
         ) : (
           <div className="absolute inset-0 flex flex-col items-center justify-center text-green-900 p-8">
             <Code2 className="w-12 h-12 mb-4 opacity-50" />
             <p className="text-[10px] font-mono text-center animate-pulse">CONNECTING DISPLAY...</p>
           </div>
         )}
       </div>
    </div>
  );
};

function App() {
  const [isBooted, setIsBooted] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [files, setFiles] = useState<AttachedFile[]>([]);
  const [processingState, setProcessingState] = useState<ProcessingState>(ProcessingState.IDLE);
  const [viewMode, setViewMode] = useState<'chat' | 'split'>('split'); // DEFAULT TO SPLIT VIEW
  const [isCloudOpen, setIsCloudOpen] = useState(false);
  const [previewContent, setPreviewContent] = useState<string | null>(null);
  const [currentUser, setCurrentUser] = useState<UserIdentity | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { const isInstalled = storageService.checkInstallation(); if (isInstalled) { setIsBooted(true); loadSystem(); } }, []);
  useEffect(() => { const code = extractPreviewCode(messages); if (code) setPreviewContent(code); }, [messages]);

  const loadSystem = () => {
    initializeChat();
    let identity = storageService.loadIdentity();
    if (!identity) { identity = collaborationService.generateIdentity(); storageService.saveIdentity(identity); }
    setCurrentUser(identity);
    collaborationService.broadcast({ type: 'PRESENCE_JOIN', payload: identity });
    const history = storageService.loadMessages();
    
    // DEFAULT VISUAL HTML TO FORCE PREVIEW
    const defaultHtml = `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <script src="https://cdn.tailwindcss.com"></script>
        <style>@keyframes scan { 0% {top:0} 50% {top:100%} 100% {top:0} }</style>
      </head>
      <body class="bg-black text-green-500 h-screen flex flex-col items-center justify-center font-mono overflow-hidden">
         <div class="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20"></div>
         <div class="z-10 text-center border-2 border-green-500 p-8 rounded-lg bg-green-900/20 shadow-[0_0_30px_rgba(34,197,94,0.3)]">
            <h1 class="text-4xl font-black mb-2 tracking-tighter">SYSTEM ONLINE</h1>
            <div class="h-1 w-full bg-green-500/50 mb-4"></div>
            <p class="text-sm font-bold animate-pulse">PREVIEW MODULE ACTIVE</p>
         </div>
      </body>
      </html>
    `;

    if (history && history.length > 0) {
      setMessages(history);
    } else {
      setMessages([{ 
        id: 'init', 
        role: 'model', 
        text: `**ATS AYEL OMEGA INITIALIZED.**\n\nVisual Link Established. Monitoring active.\n\n\`\`\`html\n${defaultHtml}\n\`\`\``, 
        timestamp: Date.now() 
      }]);
    }
  };

  const handleSendMessage = async () => {
    if ((!inputText.trim() && files.length === 0) || processingState !== ProcessingState.IDLE || !currentUser) return;
    const newUserMessage: Message = { id: Date.now().toString(), role: 'user', sender: currentUser, text: inputText, timestamp: Date.now(), attachments: [...files] };
    setMessages(prev => [...prev, newUserMessage]);
    setInputText('');
    setFiles([]);
    setProcessingState(ProcessingState.THINKING);
    collaborationService.broadcast({ type: 'USER_MSG', payload: newUserMessage });
    try {
      const aiMessageId = (Date.now() + 1).toString();
      const aiPlaceholder: Message = { id: aiMessageId, role: 'model', text: '', timestamp: Date.now() };
      await new Promise(r => setTimeout(r, 600));
      setMessages(prev => [...prev, aiPlaceholder]);
      collaborationService.broadcast({ type: 'AI_MSG_START', payload: aiPlaceholder });
      setProcessingState(ProcessingState.STREAMING);
      const stream = await sendMessageStream(newUserMessage.text, newUserMessage.attachments || []);
      let fullText = '';
      for await (const chunk of stream) { fullText += chunk; setMessages(prev => prev.map(msg => msg.id === aiMessageId ? { ...msg, text: fullText } : msg)); collaborationService.broadcast({ type: 'AI_MSG_CHUNK', payload: { id: aiMessageId, text: fullText } }); }
      setProcessingState(ProcessingState.IDLE);
    } catch (error) { setProcessingState(ProcessingState.ERROR); setMessages(prev => [...prev, { id: Date.now().toString(), role: 'model', text: "SYSTEM ERROR: API REJECTED REQUEST.", timestamp: Date.now(), isError: true }]); }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => { if (e.target.files) { const newFiles = []; for (let i = 0; i < e.target.files.length; i++) newFiles.push(await readFileContent(e.target.files[i])); setFiles(prev => [...prev, ...newFiles]); } if (fileInputRef.current) fileInputRef.current.value = ''; };

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages, processingState]);

  return (
    <div className="relative w-[380px] h-[800px] bg-black rounded-[3rem] shadow-[0_0_80px_rgba(34,197,94,0.3)] border-[6px] border-zinc-900 ring-1 ring-green-500/30 overflow-hidden font-sans">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-7 bg-black rounded-b-2xl z-50"></div>
      <div className="w-full h-full bg-[#050505] text-slate-100 flex flex-col relative overflow-hidden rounded-[2.5rem]">
        <StatusBar />
        {!isBooted ? <BootLoader onComplete={() => { storageService.completeInstallation(); setIsBooted(true); loadSystem(); }} /> : (
          <>
            <div className="flex items-center justify-between px-4 py-2 border-b border-green-900/30 bg-green-950/10 backdrop-blur-md z-30 mt-6 shrink-0">
               <div className="flex items-center gap-2">
                 <Terminal className="w-4 h-4 text-green-500 animate-pulse" />
                 <span className="text-[10px] font-bold text-green-500 font-mono tracking-widest">OMEGA::NET</span>
               </div>
               <div className="flex gap-2">
                 <button onClick={() => setViewMode(viewMode === 'chat' ? 'split' : 'chat')} className={`p-1.5 rounded bg-white/5 ${viewMode === 'split' ? 'text-green-400 shadow-[0_0_10px_rgba(34,197,94,0.3)]' : 'text-slate-400'}`}><Layout className="w-4 h-4"/></button>
                 <button onClick={() => setIsCloudOpen(true)} className="p-1.5 rounded bg-white/5 text-slate-400"><Server className="w-4 h-4"/></button>
                 <button onClick={() => { setMessages([]); loadSystem(); }} className="p-1.5 rounded bg-white/5 text-slate-400 hover:text-red-400"><RefreshCw className="w-4 h-4"/></button>
               </div>
            </div>

            <div className="flex-1 flex flex-col overflow-hidden relative">
               {isCloudOpen && <CloudConsole onClose={() => setIsCloudOpen(false)} latestHtml={previewContent} />}
               
               {/* SPLIT LAYOUT LOGIC - FIXED HEIGHTS FOR VISIBILITY */}
               <div className="flex-1 flex flex-col h-full overflow-hidden">
                 
                 {/* CHAT SECTION */}
                 <div className={`flex flex-col overflow-hidden bg-black/90 transition-all duration-300 ${viewMode === 'split' ? 'h-[45%] border-b border-green-900/30' : 'h-full'}`}>
                    <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 scrollbar-none pb-4">
                      {messages.map((msg) => (
                        <div key={msg.id} className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                          <div className={`w-6 h-6 rounded-full flex-shrink-0 flex items-center justify-center border ${msg.role === 'model' ? 'border-green-500 bg-green-900/20' : 'border-slate-700 bg-slate-800'}`}>
                            {msg.role === 'model' ? <Bot className="w-3 h-3 text-green-500" /> : <span className="text-[8px] font-bold text-white">{currentUser?.initials}</span>}
                          </div>
                          <div className={`flex flex-col max-w-[85%] space-y-1 ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                             {msg.attachments && msg.attachments.length > 0 && <div className="flex flex-wrap gap-1 mb-1 justify-end">{msg.attachments.map((f, i) => <div key={i} className="bg-zinc-900 border border-zinc-700 px-2 py-1 rounded text-[8px] text-slate-300 flex items-center gap-1"><FileCode className="w-3 h-3" /> {f.name}</div>)}</div>}
                             <div className={`px-3 py-2 rounded-xl text-xs font-mono ${msg.role === 'user' ? 'bg-zinc-800 text-white' : 'bg-green-950/10 text-green-400 border border-green-900/20 shadow-[0_0_10px_rgba(34,197,94,0.1)]'}`}>
                                {msg.role === 'model' ? <MarkdownRenderer content={msg.text} /> : <div className="whitespace-pre-wrap">{msg.text}</div>}
                             </div>
                          </div>
                        </div>
                      ))}
                      {processingState === ProcessingState.THINKING && <ThinkingIndicator />}
                      <div ref={messagesEndRef} className="h-4" />
                    </div>
                 </div>
                 
                 {/* PREVIEW SECTION - Adjusted height to account for input bar */}
                 {viewMode === 'split' && (
                    <div className="h-[55%] flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-300 pb-20 bg-[#050505]">
                        <PreviewWindow htmlContent={previewContent} />
                    </div>
                 )}

               </div>
            </div>

            <div className={`absolute bottom-0 left-0 w-full bg-black/80 backdrop-blur-md border-t border-green-900/30 px-3 pt-2 pb-6 z-40 ${viewMode === 'split' ? 'translate-y-0' : ''}`}>
              {files.length > 0 && (
                <div className="flex gap-2 overflow-x-auto pb-2 mb-1 scrollbar-none">{files.map((f, i) => (<div key={i} className="flex items-center gap-2 bg-zinc-800 rounded px-2 py-1 flex-shrink-0"><span className="text-[8px] text-white truncate max-w-[100px]">{f.name}</span><button onClick={() => setFiles(prev => prev.filter((_, idx) => idx !== i))}><X className="w-3 h-3 text-slate-400" /></button></div>))}</div>
              )}
              <div className="flex gap-2 items-center">
                <input type="file" multiple ref={fileInputRef} onChange={handleFileUpload} className="hidden" id="mobile-upload" />
                <label htmlFor="mobile-upload" className="p-2 rounded-full bg-zinc-800 text-slate-300 border border-zinc-700"><Paperclip className="w-4 h-4" /></label>
                <div className="flex-1 bg-zinc-900 rounded-full border border-zinc-800 focus-within:border-green-500/50 transition-all flex items-center px-4">
                  <input value={inputText} onChange={(e) => setInputText(e.target.value)} placeholder="ENTER TARGET..." className="w-full bg-transparent text-green-500 placeholder-green-900/50 text-xs py-3 focus:outline-none font-mono font-bold" />
                </div>
                <button onClick={handleSendMessage} disabled={processingState !== ProcessingState.IDLE} className="p-2 rounded-full bg-green-600 text-black shadow-[0_0_15px_rgba(34,197,94,0.5)]">
                  {processingState !== ProcessingState.IDLE ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default App;